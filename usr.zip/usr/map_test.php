<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Overlay</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://openlayers.org/en/v6.3.1/css/ol.css" type="text/css">
    <script src="https://openlayers.org/en/v6.3.1/build/ol.js"></script>
    <style>
        .map {
            width: 100%;
            height: 400px;
        }

        #marker {
            width: 20px;
            height: 20px;
            border: 1px solid #088;
            border-radius: 10px;
            background-color: #0FF;
            opacity: 0.5;
        }

        #vienna {
            text-decoration: none;
            color: white;
            font-size: 11pt;
            font-weight: bold;
            text-shadow: black 0.1em 0.1em 0.2em;
        }

        .popover-body {
            min-width: 276px;
        }
    </style>
</head>

<body>
    <div id="map" class="map"></div>
    <div style="display: none;">
        <!-- Clickable label for Vienna -->
        <a class="overlay" id="vienna" target="_blank" href="https://en.wikipedia.org/wiki/Vienna">Vienna</a>
        <div id="marker" title="Marker"></div>
        <!-- Popup -->
        <div id="popup"></div>
    </div>

    <script>
        var map = new ol.Map({
            target: 'map',
            layers: [
                new ol.layer.Tile({
                    source: new ol.source.OSM()
                })
            ],
            view: new ol.View({
                center: [0, 0],
                zoom: 2
            })
        });

        const pos = ol.proj.fromLonLat([16.3725, 48.208889]);

        // Popup showing the position the user clicked
        const popup = new ol.Overlay({
            element: document.getElementById('popup'),
        });
        map.addOverlay(popup);

        // Vienna marker
        const marker = new ol.Overlay({
            position: pos,
            positioning: 'center-center',
            element: document.getElementById('marker'),
            stopEvent: false,
        });
        map.addOverlay(marker);

        // Vienna label
        const vienna = new ol.Overlay({
            position: pos,
            element: document.getElementById('vienna'),
        });
        map.addOverlay(vienna);

        const element = popup.getElement();
        map.on('click', function(evt) {
            const coordinate = evt.coordinate;
            const hdms = ol.coordinate.toStringHDMS(ol.proj.toLonLat(coordinate));
            popup.setPosition(coordinate);
            let popover = bootstrap.Popover.getInstance(element);
            if (popover) {
                popover.dispose();
            }
            
            popover = new bootstrap.Popover(element, {
                animation: false,
                container: element,
                content: '<p>The location you clicked was:</p><code>' + hdms + '</code>',
                html: true,
                placement: 'top',
                title: 'Welcome to OpenLayers',
            });
            popover.show();
        });
    </script>

    <!-- Pointer events polyfill for old browsers, see https://caniuse.com/#feat=pointer -->
    <script src="https://cdn.jsdelivr.net/npm/elm-pep@1.0.6/dist/elm-pep.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- <script type="module" src="main.js"></script> -->
</body>

</html>