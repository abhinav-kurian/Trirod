<?php
session_start();
include('vendor/inc/config.php');
include('vendor/inc/checklogin.php');
check_login();
$u_id = $_SESSION['u_id'];

// Get the driver ID from the AJAX request
$driver_id = $_POST['d_id'];

// Check if the driver is already in the user's favorites

$sql = "SELECT * FROM favorites WHERE u_id = $u_id AND d_id = $driver_id";
$result = $mysqli->query($sql);
if ($result->num_rows > 0) {
    echo json_encode(array('status' => 'error', 'message' => 'This driver is already in your favorites'));
    exit;
}

// Add the driver to the user's favorites
$sql = "INSERT INTO favorites (u_id, d_id) VALUES ($u_id, $driver_id)";
if ($mysqli->query($sql) === TRUE) {
    echo json_encode(array('status' => 'success', 'message' => 'driver added to favorites'));
} else {
    echo json_encode(array('status' => 'error', 'message' => 'Failed to add driver to favorites'));
}
