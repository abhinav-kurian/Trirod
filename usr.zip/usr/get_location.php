<?php
include('vendor/inc/config.php');
// j^xuC+wKyF1hFuRs

//$sql= "SELECT * FROM locations INNER JOIN trirod_driver ON locations.d_id = trirod_driver.d_id WHERE DATE(`time`) = CURDATE()";
  $sql= "SELECT * FROM locations INNER JOIN trirod_driver ON locations.d_id = trirod_driver.d_id WHERE `time` >=DATE_SUB( now(),  interval 30 minute);";
$result = $mysqli->query($sql);

// Build an array of location data
$locations = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $locations[] = array(
            'latitude' => $row['lat'],
            'longitude' => $row['lng'],
            'name'=>$row['d_name'],
            'phone'=>$row['d_phone'],
            'regNo'=>$row['d_regno'],
            'place'=>$row['d_place'],
            'd_id'=>$row['d_id']
            
        );
    }
}

// Return the location data in JSON format
header('Content-Type: application/json');
echo json_encode($locations);

// Close the database connection
$mysqli->close();