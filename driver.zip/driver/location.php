<?php
session_start();
include('vendor/inc/config.php');
include('vendor/inc/checklogin.php');
check_login();
$d_id = $_SESSION['d_id'];

if (isset($_POST['lat']) && isset($_POST['lng'])) {
    $lat = $_POST['lat'];
    $lng = $_POST['lng'];
    $d_id = $_SESSION['d_id'];

$check_user="select * from trirod_driver where d_id= '$d_id' ";
    $result_1 = $mysqli->query($check_user);
if ($result_1) {
   

    $check_sql = "select * from locations where d_id= '$d_id' ";
    $result = $mysqli->query($check_sql);
    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $upd_sql = "update locations set lat='$lat',lng='$lng' WHERE d_id='$d_id'";
            if ($mysqli->query($upd_sql) === TRUE) {
                echo "loc updated successfully";
            } else {
                echo "Error updating record: " . $mysqli->error;
            }
        } else {
            $sql = "INSERT INTO locations (d_id,lat, lng) VALUES ('$d_id','$lat', '$lng')";
            if ($mysqli->query($sql) === TRUE) {
                echo "loc inserted successfully";
            } else {
                echo "Error updating record: " . $mysqli->error;
            }
        }
    } else {
        echo "error result";
    }
}else {
        echo "no user";
}
} else {
    echo " error";
}
