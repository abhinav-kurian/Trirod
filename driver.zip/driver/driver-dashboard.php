<?php
session_start();
include('vendor/inc/config.php');
include('vendor/inc/checklogin.php');
check_login();
$d_id = $_SESSION['d_id'];
?>
<!DOCTYPE html>
<html lang="en">

<!--Head-->
<?php include('vendor/inc/head.php'); ?>

<!--End Head-->


<body id="page-top">
  <!--Navbar-->
  <?php include('vendor/inc/nav.php'); ?>
  <!--End Navbar-->

  <div id="wrapper">

    <!-- Sidebar -->
    <?php include('vendor/inc/sidebar.php'); ?>
    <!--End Sidebar-->

    <div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="user-dashboard.php">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Overview</li>
        </ol>

        <!-- content  -->
        <?php
        if ($num_of_rows > 0) {


        ?>

          <div class="card col-md-8">
            <div class="card-body">
              <h5 class="card-title"><?php echo $row->d_name; ?> </h5>
            </div>
            <ul class="list-group list-group-flush">

              <li class="list-group-item"><b>Contact:</b> <?php echo $row->d_phone; ?></li>
              <li class="list-group-item"><b>Email Address:</b> <?php echo $row->d_email; ?></li>
              <li class="list-group-item"><b>License:</b> <?php echo $row->d_license; ?></li>
              <li class="list-group-item"><b>Reg No.:</b> <?php echo $row->d_regno; ?></li>

            <?php } else {
            echo " err_";
          } ?>
            </ul>
            <div class="card-body">
              <button class="btn btn-outline-success card-link " id="btnStart" onclick="startTimer()"><i class="fas fa-location-arrow"></i> Start location sharing</button>
              <button class="btn btn-outline-danger card-link" id="btnStop"><i class="fas fa-exclamation-circle"></i> Stop location sharing</button>
            </div>
          </div>


          <!-- <button id="btnStart">Get Location</button>
          <button id="btnStop">stop</button> -->
          <!-- <p id="location"></p> -->
          <script>
            // var timeout;

            function sendLocation() {
              if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                  var lat = position.coords.latitude;
                  var lng = position.coords.longitude;
                  // $("#location").html("Latitude: " + position.coords.latitude +
                  //   "<br>Longitude: " + position.coords.longitude);
                  $.ajax({
                    type: "POST",
                    url: "location.php",
                    data: {
                      lat: lat,
                      lng: lng
                    },
                    success: function(data) {
                      console.log("Location sent to database");
                      // timeout = setTimeout(sendLocation, 600000); // 10 seconds in milliseconds
                    },
                    error: function(xhr) {
                      console.log("error" + xhr.statusText);
                    }
                  });
                });
              } else {
                console.log("Geolocation is not supported by this browser.");
              }
            }

            var timerRunning = false;

            function startTimer() {
              if (confirm("are you sure?")) {
                if (!timerRunning) {
                  timerRunning = true;
                  intervalId = setInterval(sendLocation, 600000);


                }
                sendLocation();
              }
            }


            $("#btnStop").click(function() {
              if (confirm("are you sure ?")) {
                
              
              clearInterval(intervalId);
              console.log("Sending location to database stopped");

              }
            });
          </script>





          <!-- <script>
            // var timeout;

            function sendLocation() {
              if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                  var lat = position.coords.latitude;
                  var lng = position.coords.longitude;
                  // $("#location").html("Latitude: " + position.coords.latitude +
                  //   "<br>Longitude: " + position.coords.longitude);
                  $.ajax({
                    type: "POST",
                    url: "location.php",
                    data: {
                      lat: lat,
                      lng: lng
                    },
                    success: function(data) {
                      console.log("Location sent to database");
                      // timeout = setTimeout(sendLocation, 600000); // 10 seconds in milliseconds
                    },
                    error: function(xhr) {
                      console.log("error" + xhr.statusText);
                    }
                  });
                });
              } else {
                console.log("Geolocation is not supported by this browser.");
              }
            };
            intervalId = setInterval(sendLocation, 30000);
            sendLocation();

            $("#btnStop").click(function() {
              clearInterval(intervalId);
              console.log("Sending location to database stopped");
            });
          </script> -->


          <!-- <script>
            var interval;
            $(document).ready(function() {
              $("#btnStart").click(function() {
                interval = setInterval(function() {
                  if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(function(position) {
                      $("#location").html("Latitude: " + position.coords.latitude +
                        "<br>Longitude: " + position.coords.longitude);
                      var lat = position.coords.latitude;
                      var lng = position.coords.longitude;

                      $.ajax({
                        type: "POST",
                        url: "location.php",
                        data: {
                          lat: lat,
                          lng: lng
                        },
                        success: function(data) {
                          console.log("Location sent to database");
                        }
                      });
                    });
                  } else {
                    console.log("Geolocation is not supported by this browser.");
                  }
                }, 10000);
              });
              $("#btnStop").click(function() {
                clearInterval(interval);
                console.log("Sending location to database stopped");
              });
            });
          </script> -->


          <!-- /content -->
      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <?php include("vendor/inc/footer.php"); ?>

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-danger" href="user-logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <!-- <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script> -->

  <!--  get location -->


  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->



  <!-- Custom scripts for all pages-->
  <script src="vendor/js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->


</body>

</html>