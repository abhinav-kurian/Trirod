<!--Server Side Scripting To inject Login-->
<?php
session_start();
include('vendor/inc/config.php');
//include('vendor/inc/checklogin.php');
//check_login();
//$aid=$_SESSION['a_id'];
//Add USer
if (isset($_POST['add_driver'])) {

  $d_name = $_POST['d_name'];
  // $d_lname = $_POST['d_lname'];
  $d_phone = $_POST['d_phone'];
  $d_regno = $_POST['d_regno'];
  $d_place = $_POST['d_place'];
  $d_license = $_POST['d_license'];
  $d_gender = $_POST['d_gender'];

  $d_email = $_POST['d_email'];
  $d_pwd = $_POST['d_pwd'];

  $query = "INSERT INTO `trirod_driver`( `d_name`,`d_place`,`d_phone`, `d_email`,`d_license`,`d_regno`,  `d_gender`, `d_pwd`) values(?,?,?,?,?,?,?,?)";
  $stmt = $mysqli->prepare($query);
  $rc = $stmt->bind_param('ssssssss', $d_name, $d_place, $d_phone, $d_email, $d_license, $d_regno,  $d_gender,  $d_pwd);
  $stmt->execute();
  if ($stmt) {
    $succ = "Account Created Proceed To Log In";
  } else {
    $err = "Please Try Again Later";
  }
}
?>
<!--End Server Side Scriptiong-->
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Tranport Management System, Saccos, Matwana Culture">
  <meta name="author" content="MartDevelopers ">

  <title>Triroad driver - Register</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="vendor/css/sb-admin.css" rel="stylesheet">

</head>

<body class="usr_bg">
  <?php if (isset($succ)) { ?>
    <!--This code for injecting an alert-->
    <script>
      setTimeout(function() {
          swal("Success!", "<?php echo $succ; ?>!", "success");
        },
        100);
    </script>

  <?php } ?>
  <?php if (isset($err)) { ?>
    <!--This code for injecting an alert-->
    <script>
      setTimeout(function() {
          swal("Failed!", "<?php echo $err; ?>!", "Failed");
        },
        100);
    </script>

  <?php } ?>
  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Create An Account With Us</div>
      <div class="card-body">
        <!--Start Form-->
        <form method="post">
          <div class="form-group">
            <div class="form-row ">
              <div class="col-md-5">
                <div class="form-label-group">
                  <input type="text" required class="form-control" id="exampleInputEmail1" name="d_name">
                  <label for="firstName">Name</label>
                </div>
                <div class="form-label-group mt-3">
                  <input type="text" required class="form-control" id="exampleInputEmail1" name="d_place">
                  <label for="place">place</label>
                </div>
              </div>
              <!-- <div class="col-md-4">
                <div class="form-label-group">
                  <input type="text" class="form-control" id="exampleInputEmail1" name="d_lname">
                  <label for="lastName">Last name</label>
                </div>
              </div> -->
              <div class="col-md-4 mx-3">
                <div class="form-label-group">
                  <input type="text" class="form-control" id="exampleInputEmail1" name="d_phone">
                  <label for="lastName">Contact</label>
                </div>
              </div>
            </div>
          </div>

          <div class="form-group">

            <label for="exampleFormControlSelect1">Gender</label>
            <select class="form-control" name="d_gender" id="exampleFormControlSelect1">
              <option>select</option>
              <option value="male">male</option>
              <option value="female">female</option>
              <option value="Prefer not to respond">Prefer not to respond</option>

            </select>

          </div>



          <div class="form-group">
            <div class="form-label-group">
              <input type="text" class="form-control" name="d_license">
              <label for=" text">License No.</label>
            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">
              <input type="text" class="form-control" name="d_regno">
              <label for=" text">Reg No.</label>
            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">
              <input type="email" class="form-control" name="d_email">
              <label for=" inputEmail">Email address</label>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                <div class="form-label-group">
                  <input type="text" class="form-control" name="d_pwd" id="exampleInputPassword1">
                  <label for="inputPassword">Password</label>
                </div>
              </div>
            </div>
          </div>
          <button type="submit" name="add_driver" class="btn btn-success">Create Account</button>
        </form>
        <!--End FOrm-->
        <div class="text-center">
          <a class="d-block small mt-3" href="index.php">Login Page</a>
          <a class="d-block small" href="driver-forgot-password.php">Forgot Password?</a>
        </div>

      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <!--INject Sweet alert js-->
  <script src="vendor/js/swal.js"></script>

</body>

</html>