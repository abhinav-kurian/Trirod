<?php
include('vendor/inc/config.php');
$u_id = $_GET['u_id'];
$sql = "delete from trirod_user where d_id= '$u_id' ";
if ($conn->query($sql) === TRUE) {
    header("location:http://localhost/gtec_trirod/admin/admin-view-user.php");
} else {
    echo 'err';
}
$conn->close();
