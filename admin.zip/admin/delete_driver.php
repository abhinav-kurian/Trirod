<?php
include('vendor/inc/config.php');
$d_id = $_GET['d_id'];
$sql = "delete from trirod_driver where d_id= '$d_id' ";
$sql2 = "delete from locations where d_id= '$d_id' ";
if (($conn->query($sql) && $conn->query($sql2)) === TRUE) {
   header("location:http://localhost/gtec_trirod/admin/admin-view-drivers.php");
}else {
    echo 'err';
}
$conn->close();
