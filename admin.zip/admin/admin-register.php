<!--Server Side Scripting To inject Login-->
<?php
session_start();
include('vendor/inc/config.php');
//  include('vendor/inc/checklogin.php');
//  check_login();
// $a_id = $_SESSION['a_id'];
//Add admin
if (isset($_POST['add_admin'])) {

  $a_name = $_POST['a_name'];
  // $a_lname = $_POST['a_lname'];
  $a_email = $_POST['a_email'];
  $a_pwd = $_POST['a_pwd'];

  $query = "insert into trirod_admin (a_name,  a_email, a_pwd) values(?,?,?)";
  $stmt = $conn->prepare($query);
  $rc = $stmt->bind_param('sss', $a_name,  $a_email, $a_pwd);
  $stmt->execute();
  if ($stmt) {
    $succ = "Account Created Proceed To Log In";
  } else {
    $err = "Please Try Again Later";
  }
}
?>
<!--End Server Side Scriptiong-->
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Tranport Management System, Saccos, Matwana Culture">
  <meta name="author" content="MartDevelopers ">

  <title>Trirod admin - Register</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="vendor/css/sb-admin.css" rel="stylesheet">

</head>

<body class="bg-dark">
  <?php if (isset($succ)) { ?>
    <!--This code for injecting an alert-->
    <script>
      setTimeout(function() {
          swal("Success!", "<?php echo $succ; ?>!", "success");
        },
        100);
    </script>

  <?php } ?>
  <?php if (isset($err)) { ?>
    <!--This code for injecting an alert-->
    <script>
      setTimeout(function() {
          swal("Failed!", "<?php echo $err; ?>!", "Failed");
        },
        100);
    </script>

  <?php } ?>
  <div class="container ">
    <div class="card card-register mx-auto   my-5">
      <div class="card-header">Create An Account With Us</div>
      <div class="card-body">
        <!--Start Form-->
        <form method="post">
          <div class="form-group">

            <div class="col">
              <div class="form-label-group">
                <input type="text" required class="form-control" id="exampleInputEmail1" name="a_name">
                <label for="firstName">Name</label>
              </div>
            </div>
            <!-- <div class="col-md-4">
                <div class="form-label-group">
                  <input type="text" class="form-control" id="exampleInputEmail1" name="a_lname">
                  <label for="lastName">Last name</label>
                </div>
              </div> -->
            <!-- <div class="col-md-4">
                <div class="form-label-group">
                  <input type="text" class="form-control" id="exampleInputEmail1" name="a_phone">
                  <label for="lastName">Contact</label>
                </div>
              </div> -->

          </div>


          <div class="form-group col">
            <div class="form-label-group">
              <input type="email" class="form-control" name="a_email">
              <label for=" inputEmail">Email address</label>
            </div>
          </div>
          <div class="form-group col">
            <div class="form-row">
              <div class="col-md-12">
                <div class="form-label-group">
                  <input type="password" class="form-control" name="a_pwd" id="exampleInputPassword1">
                  <label for="inputPassword">Password</label>
                </div>
              </div>
            </div>
          </div>
          <div class="text-center">
            <button type="submit" name="add_admin" class="btn btn-success  ">Create Account</button>
          </div>
        </form>
        <!--End FOrm-->
        <div class="text-center">
          <a class="d-block small mt-3" href="index.php">Login Page</a>
          <a class="d-block small" href="admin-forgot-pwd.php">Forgot Password?</a>
        </div>

      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <!--INject Sweet alert js-->
  <script src="vendor/js/swal.js"></script>

</body>

</html>